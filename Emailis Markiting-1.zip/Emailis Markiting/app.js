const express = require("express");
const nodemailer = require("nodemailer");
const multer = require("multer");
const ejs = require("ejs");
const path = require("path");
const emails = require("./emails.json");

// Set The Storage Engine
const storage = multer.diskStorage({
  destination: "./public/uploads/",
  filename: function (req, file, cb) {
    cb(
      null,
      file.fieldname + "-" + Date.now() + path.extname(file.originalname)
    );
  },
});

// Init Upload
const upload = multer({
  storage: storage,
  limits: { fileSize: 1000000 },
  fileFilter: function (req, file, cb) {
    checkFileType(file, cb);
  },
}).single("myImage");

// Check File Type
function checkFileType(file, cb) {
  // Allowed ext
  const filetypes = /jpeg|jpg|png|gif/;
  // Check ext
  const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
  // Check mime
  const mimetype = filetypes.test(file.mimetype);

  if (mimetype && extname) {
    return cb(null, true);
  } else {
    cb("Error: Images Only!");
  }
}

// Init app
const app = express();

// EJS
app.set("view engine", "ejs");

// Public Folder
app.use(express.static("./public"));

app.get("/", (req, res) => res.render("index"));

app.post("/upload", (req, res) => {
  upload(req, res, (err) => {
    if (err) {
      res.render("index", {
        msg: err,
      });
    } else {
      if (req.file == undefined) {
        const output = `
          <h3>Message</h3>
          <p>${req.body.message}</p>
         `;

        // creat reusable transporter object using the default SMTP transport
        let transporter = nodemailer.createTransport({
          host: "smtp.gmail.com",
          port: 465,
          secure: true,
          auth: {
            user: "amnnn80@gmail.com",
            pass: "", // Your pass word
          },
          tls: {
            rejectUnauthorized: false,
          },
        });
        // aray of all recivers
        let allRecevers = [];
        emails.forEach(element => {
          allRecevers.push(element.NO);
        });

        // setup email with unicode symbols

        let mailOptions = {
          from: "متجر البضائع السعودية",
          bcc: allRecevers,
          subject: req.body.subject,
          text: "Hi",
          html: output,
        };

        // send mail with defined transport object
        transporter.sendMail(mailOptions, (error, info) => {
          if (error) {
            return console.log(error);
          }
          console.log("message sent: %s", info.messageId);
          console.log("preview URL: %s", nodemailer.getTestMessageUrl(info));
          res.render("index", {
            msg: "email has been sent",
          });
        });
      } else {
        const output = `
          <p>${req.body.message}</p>
         `;

        // creat reusable transporter object using the default SMTP transport
        let transporter = nodemailer.createTransport({
          host: "smtp.gmail.com",
          port: 465,
          secure: true,
          auth: {
            user: "amnnn80@gmail.com",
            pass: "" //your password,
          },
          tls: {
            rejectUnauthorized: false,
          },
        });
        // aray of all recivers
        let allRecevers = [];
        emails.forEach(element => {
          allRecevers.push(element.NO);
        });
        // setup email with unicode symbols

        let mailOptions = {
          from: "متجر البضائع السعودية",
          bcc: allRecevers,
          subject: req.body.subject,
          text: "Hi",
          html: output,
          attachments: [
            {
              path: `./public/uploads/${req.file.filename}`,
            },
          ],
        };

        // send mail with defined transport object
        transporter.sendMail(mailOptions, (error, info) => {
          if (error) {
            return console.log(error);
          }
          console.log("message sent: %s", info.messageId);
          console.log("preview URL: %s", nodemailer.getTestMessageUrl(info));
          res.render("index", {
            msg: "email has been sent",
            file: `uploads/${req.file.filename}`,
          });
        });
      }
    }
  });
});

const port = 3000;

app.listen(port, () => console.log(`Server started on port ${port}`));
